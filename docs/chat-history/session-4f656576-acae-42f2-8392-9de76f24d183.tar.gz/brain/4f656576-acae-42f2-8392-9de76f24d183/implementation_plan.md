# Parçalı Maaş/Alacak Takibi ve Banka Hareketlerini Tahsilat Olarak Eşleme Mimarisi

Bu plan, kullanıcının işten ayrılış sonrası maaş alacaklarını ay ay/parça parça şaşırmadan takip edebilmesini ve banka hareketleri listesinden herhangi bir gelen parayı tek tıkla ilgili alacağa "Tahsilat" olarak bağlayabilmesini sağlar.

## Kullanıcı İncelemesi ve Karar Gerektiren Noktalar

> [!IMPORTANT]
> **Açık Soru 1: 149.850 TL Maaş Alacağının Parçaları**
> Sistemde şu an `149.850,00 TL` tek bir açık alacak olarak kayıtlı. Bunu "maaş maaş ödemesini şaşırmayayım" talebin doğrultusunda dönemlere/parçalara bölmek istiyoruz.
> * Örneğin:
>   * *Seçenek A*: Nisan 2026 Maaşı, Mayıs 2026 Maaşı, Haziran 2026 Maaşı, Kıdem/İhbar Tazminatı
>   * *Seçenek B*: Belirli sabit tutarlı taksitler (örn: 3 x 49.950 TL veya senin vereceğin net aylık rakamlar).
> Lütfen bu tutarın hangi parça ve açıklamalara bölünmesini istediğini belirt.

> [!NOTE]
> **İki Yönlü Eşleme Deneyimi (Transactions ↔ Debts)**
> Tahsilat bağlama özelliğini hem **Hareketler (`/transactions`)** sayfasından hem de **Borç & Alacak (`/debts`)** sayfasından iki yönlü olarak kuruyoruz:
> 1. *Hareketler sayfasından*: Gelen para (Gelir) satırındaki "🎯 Alacağa Bağla" butonuna tıklandığında açık alacaklar açılır ve tek tıkla o alacaktan düşülür.
> 2. *Borç & Alacak sayfasından*: Alacak kartındaki "🏦 Banka Hareketinden Eşle" butonuna tıklandığında hesap dökümlerinden gelen paralar listelenir ve seçilen hareket alacağa tahsilat olarak bağlanır.

---

## Önerilen Değişiklikler

### 1. Veri Modeli ve PostgreSQL Şeması

#### [NEW] [003_link_transactions_to_debts.sql](file:///Users/evren/Documents/GitHub/pusula/supabase/migrations/003_link_transactions_to_debts.sql)
* `transactions` tablosuna `related_debt_id uuid references public.debts(id) on delete set null` sütununun ve indeksinin eklenmesi.
* `debts` tablosuna varsa eksik `project_id` sütununun güvenli eklenmesi.

---

### 2. Finans ve Köprü Motoru (Financial Bridge & Engine)

#### [MODIFY] [financial-bridge.ts](file:///Users/evren/Documents/GitHub/pusula/src/lib/financial-bridge.ts)
* `linkTransactionToDebt({ transactionId, debtId, userId })`:
  * Seçili hareketin tipini `'Tahsilat'` yapar.
  * `related_debt_id` alanını `debtId` olarak günceller.
  * İlgili borç/alacağın `past_payments` tutarını hareket tutarı kadar artırır, `remaining` tutarını düşürür (`Math.max(0, remaining - amount)`).
  * Kalan sıfırlanmışsa alacak durumunu `'Kapatıldı'` yapar.
* `unlinkTransactionFromDebt({ transactionId, userId })`:
  * Yanlışlıkla eşlenen bir hareketi eski haline döndürür: `related_debt_id` sıfırlanır, hareket tipi tekrar `'Gelir'` olur, alacağın `remaining` tutarı iade edilir.

---

### 3. Arayüz Entegrasyonu (UI / UX)

#### [MODIFY] [transactions/page.tsx](file:///Users/evren/Documents/GitHub/pusula/src/app/transactions/page.tsx)
* Gelir satırlarına hızlı aksiyon menüsü:
  * Eğer hareket henüz bir alacağa bağlı değilse: **"Alacağa Bağla"** butonu/ikonu.
  * Tıklandığında açık alacakları (Hızır Global vb.) listeleyen modal açılır.
  * Eğer hareket zaten bir alacağa bağlıysa: Yeşil rozet (Örn: `✓ Hızır Global`) ve bağlantıyı çözme seçeneği.

#### [MODIFY] [debts/page.tsx](file:///Users/evren/Documents/GitHub/pusula/src/app/debts/page.tsx)
* Alacak kartlarına **"Banka Hareketinden Seç"** modalı:
  * Kullanıcı manuel elle tutar yazmak zorunda kalmadan, son 6 ayın banka hesap hareketleri arasından (Enpara, Akbank, Ziraat, Vakıf Katılım) gelen ödemeyi seçer.
  * Seçilen hareket doğrudan o alacağın tahsilatı olarak işaretlenir.
* Parçalı Maaş görünümü:
  * Birden fazla aya ait maaş alacakları kartta veya listede şık bir zaman çizelgesi / kırılım halinde listelenir.

---

## Doğrulama Planı

### Otomatik Testler
* `npm test`: `tests/financial-bridge.test.ts` ve `tests/reconciler.test.ts` içerisine hareket eşleme (`linkTransactionToDebt`) ve bağlantı koparma (`unlinkTransactionFromDebt`) senaryoları için birim testleri eklenecek.
* `npx tsc --noEmit`: Tip güvenliği doğrulanacak.
* `npm run build`: 17 sayfalık Next.js production derlemesi test edilecek.

### Manuel Doğrulama
* `/transactions` sayfasına girilerek Hızır Global'den gelen bir ödeme seçilip maaş alacağına bağlanacak.
* `/debts` sayfasına geçilerek alacağın kalan tutarının düştüğü ve hareket geçmişine eklendiği teyit edilecek.
* `/` (Dashboard) sayfasındaki net varlık ve alacak projeksiyonunun tutarlılığı kontrol edilecek.
