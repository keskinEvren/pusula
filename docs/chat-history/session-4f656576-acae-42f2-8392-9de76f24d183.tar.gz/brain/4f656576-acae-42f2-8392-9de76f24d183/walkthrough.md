# Excel Birebir Tablo Görünümü & Hızlı Tahsilat Düşme

Kullanıcının gönderdiği Excel ekran görüntüsü (`media_1788904974842.png`) baz alınarak `/debts` sayfası tamamen yeniden düzenlendi. Ayrık kartlar veya karmaşık yapılar kaldırılarak doğrudan kullanıcının Excel tablosuyla aynı görsel ve veri yapısı oluşturuldu.

---

## 1. Tablo Yapısı ve Birebir Veri Eşleşmesi

| No | Tür | Kategori | Kişi / Kurum | Açıklama | Ana Tutar | Geçmiş Ödeme/Tahsil | Yeni Hareketlerden | Kalan | Durum |
| :-: | :--- | :--- | :--- | :--- | -: | -: | -: | -: | :--- |
| **1** | Borç | Diğer | Akbank | Artı Para | ₺74,91 | - | - | **₺74,91** | Açık |
| **2** | Alacak | Maaş | Hızır Global AŞ | Şubat Ayı Çalışması (Mart Maaşı) | ₺63.300,00 | ₺30.000,00 | ₺33.300,00 | **-** | Kapandı |
| **3** | Alacak | Maaş | Hızır Global AŞ | Mart Ayı Çalışması (Nisan Maaşı) | ₺63.300,00 | ₺25.000,00 | ₺25.600,00 | **₺12.700,00** | Açık |
| **4** | Alacak | Maaş | Hızır Global AŞ | Nisan Ayı Çalışması (Mayıs Maaşı) | ₺63.300,00 | - | - | **₺63.300,00** | Açık |
| **5** | Alacak | Maaş | Hızır Global AŞ | Mayıs Ayı Çalışması (Haziran Maaşı) | ₺63.300,00 | - | - | **₺63.300,00** | Açık |
| **6** | Alacak | Maaş | Hızır Global AŞ | Haziran Ayı Çalışması (Temmuz Maaşı) | ₺10.550,00 | - | - | **₺10.550,00** | Açık |
| **7** | Alacak | Kişisel Borç | Hızır Global AŞ | Karttan Yaptığım Harcamalar Farkı | ₺15.723,00 | - | - | **₺15.723,00** | Açık |

* **Kesin Alacaklarım (Kalan)**: `₺165.573,00`
* **Toplam Borcum (Kalan)**: `₺74,91`
* **Net Alacak Fazlası**: `+₺165.498,09`

---

## 2. Kullanıcı Deneyimi & İşlem Yetenekleri

1. **Görsel Birebirlik ([`src/app/debts/page.tsx`](file:///Users/evren/Documents/GitHub/pusula/src/app/debts/page.tsx))**:
   * Başlık koyu camgöbeği/petrol rengi (`#1d707c`) ve beyaz yazı.
   * `Yeni Hareketlerden` sütunu Excel'deki gibi hafif yeşil tonlu zemin (`bg-emerald-500/10`).
   * `Kalan` sütunu kalın yeşil yazı (`text-emerald-500 font-bold`).
2. **Ödeme Aldıkça Düşme ("Düş" Butonu)**:
   * Her satırın yanında bulunan **"Düş"** butonuna basıldığında:
     * İster elle tutar yazarak (ör. 10.000 TL),
     * İster banka hareketleri listesinden tek tıkla gelen parayı seçerek,
     ilgili satırdan ödeme düşülür.
   * Düşülen tutar anında `Yeni Hareketlerden` sütununa eklenir, `Kalan` tutarından eksilir. Kalan sıfırlandığında durum otomatik `Kapandı` (`-`) olur.
3. **Satır Düzenleme ve Ekleme**:
   * Tablodaki her satır için düzenleme ve silme desteği mevcuttur.
   * "Yeni Satır Ekle" butonu ile istenen yeni hakediş veya borç satırı eklenebilir.
