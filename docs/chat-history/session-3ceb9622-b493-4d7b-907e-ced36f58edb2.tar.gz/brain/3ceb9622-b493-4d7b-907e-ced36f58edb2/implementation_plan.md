# Projeler ve Fikirler Modülü: Markdown Düzenleyici, Canlı Önizleme ve Dosya Yönetimi

## Amaç ve Kapsam
Solo bir yazılımcı veya kurucunun aklına gelen bir projenin teknik şartnamesini, mimari notlarını veya gereksinim dosyalarını doğrudan Pusula içinde tutabilmesi hedeflenmektedir. Bu kapsamda:
- Ham Markdown metnini doğrudan kopyalayıp yapıştırabilme
- Sol tarafta kod editörü, sağ tarafta eşzamanlı canlı biçimlendirilmiş önizleme (Split View)
- Dışarıdan `.md` veya `.txt` dosyalarını sürükleyip bırakarak (Drag & Drop) veya dosya seçiciyle anında yükleme (Import)
- Proje veya fikir dokümanını tek tıkla `.md` dosyası olarak bilgisayara indirme (Export)
- Fikirler ([/ideas](file:///Users/evren/Documents/GitHub/pusula/src/app/ideas/page.tsx)) ve Proje Detayı ([/projects/[slug]](file:///Users/evren/Documents/GitHub/pusula/src/app/projects/[slug]/page.tsx)) sayfalarında kesintisiz entegrasyon

## Kullanıcı İncelemesi Gerektiren Konular
- Proje dokümanı için mevcut `projects.description` veri alanı ve yerel tarayıcı hafızası (`pusula_project_doc_${slug}`) senkronizasyonu kullanılacaktır. Bu sayede veritabanında şema kırma veya veri kaybı riski olmadan hem anlık yerel otomatik kaydetme hem de kalıcı bulut senkronizasyonu sağlanır.
- Markdown derlemesi için sıfır bağımlılıklı, React 19 ile tam uyumlu ve hafif `marked` paketi eklenecektir (~10 KB).

---

## Önerilen Değişiklikler

### 1. Markdown Çekirdek Kütüphanesi ve Yardımcıları

#### [NEW] [markdown-utils.ts](file:///Users/evren/Documents/GitHub/pusula/src/lib/markdown-utils.ts)
- `exportMarkdownFile(filename: string, content: string)`: Tarayıcıda Blob oluşturarak tek tıkla `.md` dosyasını indirir.
- `readMarkdownFile(file: File): Promise<string>`: Yüklenen veya sürüklenen `.md` / `.txt` dosyasının metin içeriğini tarayıcı API'siyle okur.
- `copyMarkdownToClipboard(content: string)`: Ham markdown metnini panoya kopyalar.

#### [NEW] [markdown-preview.tsx](file:///Users/evren/Documents/GitHub/pusula/src/components/markdown/markdown-preview.tsx)
- `marked` ile markdown metnini HTML'e dönüştürür.
- Koyu temaya (Nordic Slate) tam uyumlu başlıklar, kod blokları, listeler, görev kutucukları (`- [x]`, `- [ ]`), alıntılar ve tablolar içerir.

#### [NEW] [markdown-editor.tsx](file:///Users/evren/Documents/GitHub/pusula/src/components/markdown/markdown-editor.tsx)
- Görünüm modları:
  - `split`: Masaüstünde yan yana çift panel (Sol: Editör, Sağ: Canlı Önizleme).
  - `write`: Yalnızca metin editörü.
  - `preview`: Yalnızca biçimlendirilmiş önizleme.
- Araç çubuğu:
  - H1, H2, Kalın, İtalik, Kod Bloğu, Liste, Görev Listesi (`- [ ]`) ve Tablo ekleme kısayolları.
  - Sürükle ve bırak (Drag & Drop) dosya desteği.
  - "MD Dosyası Yükle" (Import) ve "MD Olarak İndir" (Export) butonları.
  - Tek tıkla "Panoya Kopyala" butonu.
  - Karakter ve kelime sayacı.
  - `Cmd + S` veya `Ctrl + S` kısayolu ile anında kaydetme.

---

### 2. Fikirler Modülü ([src/app/ideas/page.tsx](file:///Users/evren/Documents/GitHub/pusula/src/app/ideas/page.tsx))

#### [MODIFY] [ideas/page.tsx](file:///Users/evren/Documents/GitHub/pusula/src/app/ideas/page.tsx)
- **Yeni Fikir Ekleme Modalı**: Basit tek satırlık textarea yerine Markdown düzenleyici ve önizleme desteği.
- **Fikir Kartı Tıklaması**: Fikir kartına tıklandığında açılan detay görünümü. Fikrin tüm Markdown içeriği biçimlendirilmiş olarak incelenebilir ve doğrudan düzenlenebilir.
- **Projeye Dönüştürme**: Fikir bir projeye terfi ettirildiğinde (`handleExecutePromote`), yazılan tüm Markdown spec içeriği kaybolmadan oluşturulan projeye aktarılır.

---

### 3. Proje Detayı Modülü ([src/app/projects/[slug]/page.tsx](file:///Users/evren/Documents/GitHub/pusula/src/app/projects/[slug]/page.tsx))

#### [MODIFY] [projects/[slug]/page.tsx](file:///Users/evren/Documents/GitHub/pusula/src/app/projects/[slug]/page.tsx)
- **Dokümantasyon & Şartname (Spec) Alanı**: Proje P&L kartı ve görev listesinin altına "Proje Notları & Dokümantasyon" alanı eklenir.
- **Split View Düzenleme & Önizleme**: Kodlanan projenin mimarisi, gereksinimleri veya kopyalanan README metinleri burada canlı görüntülenir.
- **Dosya Aktarımları**: Dışarıdan `.md` dosyası yükleme, bilgisayara indirme ve panoya kopyalama özellikleri doğrudan proje üzerinde çalışır.

---

## Doğrulama Planı

### Otomatik Testler
- `npm test`: Mevcut 11 test paketinin (118 test) regresyonsuz çalışmaya devam ettiğini doğrula.
- `npx tsc --noEmit`: Tip denetiminin 0 hata verdiğini doğrula.

### Manuel Doğrulama
- Bir `.md` dosyasını editör üzerine sürükleyip bırakarak içeriğin hatasız yüklendiğini test et.
- Canlı önizlemenin (başlıklar, kod blokları, listeler) anlık olarak çalıştığını doğrula.
- "MD Olarak İndir" butonuna basarak dosyanın indiğini doğrula.
- Fikirden projeye terfi akışında markdown metninin projeye eksiksiz taşındığını test et.
